NameGen
=======

This is the start of a set of programs for creating and evaluating new
names for antibodies.

Useful links and papers
-----------------------
https://linguistics.stackexchange.com/questions/15536/similar-sounds-phonemes-words-and-word-sequences
https://linguistics.stackexchange.com/questions/20159/do-the-ipa-consonants-v-and-w-sound-similar/20160?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa


https://sourceforge.net/p/cmusphinx/discussion/help/thread/951422ba/
https://sourceforge.net/p/cmusphinx/discussion/sphinx4/thread/76f4bdde/
http://www.speech.cs.cmu.edu/tools/lextool.html
https://cmusphinx.github.io/wiki/tutorialdict/

https://github.com/vanderlee/phpSyllable
http://sylli.sourceforge.net/
https://www.nist.gov/itl/iad/mig/tools
http://www.delphiforfun.org/programs/syllables.htm
http://alias-i.com/lingpipe/demos/tutorial/hyphenation/read-me.html
https://github.com/mnater/Hyphenator
https://pypi.org/project/sylli/
https://www-i6.informatik.rwth-aachen.de/web/Software/g2p.html
https://github.com/cmusphinx/g2p-seq2seq
https://github.com/sequitur-g2p/sequitur-g2p
https://sourceforge.net/projects/cmusphinx/files/G2P%20Models/
http://montreal-forced-aligner.readthedocs.io/en/stable/g2p.html

Google: linguistics letter sound similarity matrix
Google: syllabication software open source
Google: phoneme similarity matrix
